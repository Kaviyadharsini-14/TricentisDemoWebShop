package Tricentis;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.*;

public class SelectItems {

    ChromeDriver driver;

    @BeforeTest
    public void openBrowser() {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driver.manage().window().maximize();
    }

    @BeforeMethod
    public void openURLAndLogin() {

        driver.get("https://demowebshop.tricentis.com/");

        // If already logged in → logout first
        if(driver.findElements(By.className("ico-logout")).size() > 0) {
            driver.findElement(By.className("ico-logout")).click();
        }

        driver.findElement(By.className("ico-login")).click();
        driver.findElement(By.id("Email")).sendKeys("gfhhgk@gmail.com");
        driver.findElement(By.id("Password")).sendKeys("W875Ac$URf$xN");
        driver.findElement(By.xpath("//input[@value='Log in']")).click();
    }
    @Test
    public void Books() {

        driver.findElement(By.linkText("Books")).click();
        Select select = new Select(driver.findElement(By.id("products-pagesize")));
        select.selectByIndex(1);

        driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
    }

    @Test
    public void Computer_Desktop() {

        driver.findElement(By.linkText("Computers")).click();
        driver.findElement(By.linkText("Desktops")).click();
        driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
    }

    @Test
    public void Electronics() {

        driver.findElement(By.linkText("Electronics")).click();
        driver.findElement(By.linkText("Camera, photo")).click();
    }

    @Test
    public void Apparel() {

        driver.findElement(By.linkText("Apparel & Shoes")).click();
        driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
    }

    @Test
    public void Digital() {

        driver.findElement(By.linkText("Digital downloads")).click();
        driver.findElement(By.xpath("//input[@value='Add to cart']")).click();
    }

   
}