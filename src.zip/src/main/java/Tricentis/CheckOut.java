package Tricentis;
	import java.time.Duration;
	import org.openqa.selenium.By;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.Test;
	public class CheckOut extends SelectItems{
		@Test
		public void completeCheckout() {

		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		    wait.until(ExpectedConditions.elementToBeClickable(By.className("cart-label"))).click();

		    driver.findElement(By.id("termsofservice")).click();
		    wait.until(ExpectedConditions.elementToBeClickable(By.id("checkout"))).click();

		    wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//input[@onclick='Billing.save()']")
		    )).click();

		    wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//div[@id='shipping-buttons-container']//input[@value='Continue']")
		    )).click();

		    wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//input[@class='button-1 shipping-method-next-step-button']")
		    )).click();

		    wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//input[@class='button-1 payment-method-next-step-button']")
		    )).click();

		    wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//input[@class='button-1 payment-info-next-step-button']")
		    )).click();

		    wait.until(ExpectedConditions.elementToBeClickable(
		            By.xpath("//input[@value='Confirm']")
		    )).click();
		}
		@AfterTest 
		public void closeBrowser() { driver.quit(); }
	}


